Create database final_test;

use final_test;
DROP TABLE Q2_2;

SELECT * FROM Q1;

/*Find how the average male height changed between each Olympics from 1896 to 2016. 
Output the Olympics year, average height, previous average height, 
and the corresponding average height difference. Order records by the year in ascending order.

If average height is not found, assume that the average height of an athlete is 172.73.*/
select avg(ifnull(height,172.73)) from q1 group by year;


/*Find stores that were opened in the second half of 2021 with more than 20% of their reviews 
being negative. A review is considered negative
 when the score given by a customer is below 5. Output the names of the stores together with 
 the ratio of negative reviews to positive ones.*/
SELECT * FROM q2_1; 
SELECT * FROM q2_2;

Select store_id, name, score, opening_date,
sum(case when score < 5 then 1 else 0 end) as negative,
sum(case when score > 5 then 1 else 0 end) AS positive,
sum(case when score < 5 then 1 else 0 end) / sum(case when score > 5 then 1 else 0 end) as neg_to_pos_ratio
from q2_1 a inner join q2_2 b on a.store_id = b.id 
 where 
 opening_date >= '2021-07-01' AND opening_date <= '2021-12-31'
 group by 
 store_id
 having neg_to_pos_ratio > 0.2;
 
 
 
 /* Your task is to produce a trips table that lists all the cheapest possible trips 
 that can be done in two or fewer stops. This table should have the columns origin, 
 destination and total_cost (cheapest one). Sort the output table by origin, then by 
 destination. The cities are all represented by an abbreviation composed of three uppercase English letters. 
 Note: A flight from SFO to JFK is considered to be different than a flight from JFK to SFO*/
 
 select * from q3;
 
 select e.origin, d.destination, ifnull(min(e.cost + d.cost), e.cost) cheapest_cost from q3 as e left
 join q3 as d on e.destination = d.origin
 group  by e.origin, d.destination;
 
 
 /*Write a query to print top city with highest spends and their percentage contribution of total credit card spends*/
  select * from q6;
  
  select city, (amount) as hisghest_spend, (max(amount)/sum(amount)) *100 as pecentage from q6;
  
  /* 7) Write a query to print highest spend month and amount spent in that month for each card type*/
select month(Transaction_Date) as Highest_spent_month, max(amount) spent_amount from q6 group by Card_Type;

/*8) Write a query to find city which had lowest percentage spend for gold card type*/
select city, (min(amount)/ sum(amount)) * 100 as lowest_percentage from q6 where card_type = 'Gold';


/*9) Write a query to print 3 columns: City, Highest_Expense_Type, Lowest_Expense_Type*/


/*10) Write a query to find percentage contribution f spends by females for each expense type*/ 
select 
sum(case when Gender = 'F' then amount else 0 end) Female_expenses,
sum(amount) as Total_expenses, 
round(sum(case when Gender = 'F' then amount else 0 end)/ sum(amount) *100,1) as percentage_contribution from q6 group by Exp_Type;

